INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
VALUES('12345678910',NOW(),'意式行政房','房间设计充满意大利风格，设施齐全，包括舒适的床品、高端办公设备等。服务方面提供礼宾服务、优先入住和退房、专用行政酒廊等。住客还能享受精致的餐饮服务，如意大利特色美食和定制早餐。位置和景观优越。适合追求高品质、高服务体验的旅客。','便利设施：高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...','/front/images/detail-slider/slider1.jpg',500,'N201',1,'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"><img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"><img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"><img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"><img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"><img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"><img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"><img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');



INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
VALUES('12345678910',NOW(),
'意式行政房',
'房间设计充满意大利风格，设施齐全，包括舒适的床品、高端办公设备等。服务方面提供礼宾服务、优先入住和退房、专用行政酒廊等。住客还能享受精致的餐饮服务，如意大利特色美食和定制早餐。位置和景观优越。适合追求高品质、高服务体验的旅客。',
'便利设施：高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N202',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式套房',
'房间充满意大利风格，设计精致，配备高品质的床品和舒适的设施。住客可享受VIP级别的服务，如礼宾服务、优先入住和退房、专用行政酒廊等。此外，还有意式餐饮服务和精致的客房服务。位置和景观优越，适合追求高品质、高服务体验的旅客。与意式行政房相比，意式套房更加豪华。',
'便利设施：免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N203',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式套房',
'房间充满意大利风格，设计精致，配备高品质的床品和舒适的设施。住客可享受VIP级别的服务，如礼宾服务、优先入住和退房、专用行政酒廊等。此外，还有意式餐饮服务和精致的客房服务。位置和景观优越，适合追求高品质、高服务体验的旅客。与意式行政房相比，意式套房更加豪华。',
'便利设施：免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N204',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式三人间',
'提供给三个人的住宿体验，房间设计充满意大利风格，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有意式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、高服务体验的旅客。',
'便利设施：三张床、高级床品、设施齐全的浴室、独立的起居区、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N205',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式三人间',
'提供给三个人的住宿体验，房间设计充满意大利风格，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有意式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、高服务体验的旅客。',
'便利设施：三张床、高级床品、设施齐全的浴室、独立的起居区、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N206',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式标准间',
'提供给两个人的住宿体验，房间设计以意大利风格为特色，设施齐全。床品质量高，提供舒适的睡眠环境。此外，还有高级的浴室设施、免费Wi-Fi、迷你吧等便利设施。适合情侣或夫妻旅行，追求高品质、高服务体验的旅客。',
'便利设施：免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N207',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式标准间',
'提供给两个人的住宿体验，房间设计以意大利风格为特色，设施齐全。床品质量高，提供舒适的睡眠环境。此外，还有高级的浴室设施、免费Wi-Fi、迷你吧等便利设施。适合情侣或夫妻旅行，追求高品质、高服务体验的旅客。',
'便利设施：免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N208',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式大床房',
'提供给两个人的住宿体验，房间设计以意大利风格为特色，配备大床和高品质的床品。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有意式餐饮服务和24小时客房服务。适合情侣或夫妻旅行，追求高品质、高服务体验的旅客。与意式标准间相比，意式大床房更加注重舒适和浪漫氛围。',
'便利设施：大床、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'front/images/detail-slider/slider5.jpg',
350,
'N209',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式大床房',
'提供给两个人的住宿体验，房间设计以意大利风格为特色，配备大床和高品质的床品。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有意式餐饮服务和24小时客房服务。适合情侣或夫妻旅行，追求高品质、高服务体验的旅客。与意式标准间相比，意式大床房更加注重舒适和浪漫氛围。',
'便利设施：大床、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'front/images/detail-slider/slider5.jpg',
350,
'N210',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式单间',
'提供单人住宿体验的房型，以意大利风格为设计灵感。房间配备舒适的床和高品质的床品，提供独立的浴室设施、免费Wi-Fi和迷你吧等便利设施。适合独自旅行或需要私人空间的商务旅客，营造温馨、宁静的住宿环境。',
'便利设施：免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N211',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'意式单间',
'提供单人住宿体验的房型，以意大利风格为设计灵感。房间配备舒适的床和高品质的床品，提供独立的浴室设施、免费Wi-Fi和迷你吧等便利设施。适合独自旅行或需要私人空间的商务旅客，营造温馨、宁静的住宿环境。',
'便利设施：免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N212',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'双人电竞房',
'专为电竞爱好者设计的住宿体验。房间内配备高性能电竞设备、舒适的电竞椅和双人对战空间，提供畅快的游戏体验。同时，房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、双人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'front/images/detail-slider/slider7.jpg',
200,
'N213',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'双人电竞房',
'专为电竞爱好者设计的住宿体验。房间内配备高性能电竞设备、舒适的电竞椅和双人对战空间，提供畅快的游戏体验。同时，房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、双人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'front/images/detail-slider/slider7.jpg',
200,
'N214',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式行政房',
'融合了法国的优雅与精致，房间设计充满法式风格，配备高品质的设施和床品，营造出浪漫与舒适的氛围。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还提供精致的法式早餐和24小时客房服务。适合追求高品质、优雅体验的旅客。',
'便利设施：精致的法式早餐、高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N301',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');



INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式行政房',
'融合了法国的优雅与精致，房间设计充满法式风格，配备高品质的设施和床品，营造出浪漫与舒适的氛围。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还提供精致的法式早餐和24小时客房服务。适合追求高品质、优雅体验的旅客。',
'便利设施：精致的法式早餐、高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N302',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式套房',
'豪华的住宿体验，以法国的优雅与精致为核心设计理念。房间采用法式装修风格，提供高品质的床品、舒适的起居空间和设施完备的浴室。住客可享受VIP级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的法式餐饮服务和24小时客房服务。适合追求高品质、优雅体验的旅客。',
'便利设施：精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N303',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式套房',
'豪华的住宿体验，以法国的优雅与精致为核心设计理念。房间采用法式装修风格，提供高品质的床品、舒适的起居空间和设施完备的浴室。住客可享受VIP级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的法式餐饮服务和24小时客房服务。适合追求高品质、优雅体验的旅客。',
'便利设施：精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N304',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式三人间',
'提供给三个人的住宿体验，房间设计充满法式风格，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有法式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、优雅体验的旅客。',
'便利设施：三张床、精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N305',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式三人间',
'提供给三个人的住宿体验，房间设计充满法式风格，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有法式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、优雅体验的旅客。',
'便利设施：三张床、精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N306',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式标间',
'提供给两个人的住宿体验，以法国的优雅与精致为核心设计理念。房间布局考究，采用法式装修风格，配备高品质的床品和设施。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的法式餐饮服务和24小时客房服务。适合情侣或夫妻旅行，追求高品质、优雅体验的旅客。',
'便利设施：精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N307',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式标间',
'提供给两个人的住宿体验，以法国的优雅与精致为核心设计理念。房间布局考究，采用法式装修风格，配备高品质的床品和设施。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的法式餐饮服务和24小时客房服务。适合情侣或夫妻旅行，追求高品质、优雅体验的旅客。',
'便利设施：精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N308',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式大床房',
'专为情侣或夫妻设计的住宿体验，房间以法式浪漫风格为特色。配备舒适的大床和高品质的床品，营造温馨浪漫的氛围。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，房间还提供法式浪漫晚餐和24小时客房服务。适合追求浪漫、优雅体验的旅客。',
'便利设施：大床、精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider5.jpg',
350,
'N309',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式大床房',
'专为情侣或夫妻设计的住宿体验，房间以法式浪漫风格为特色。配备舒适的大床和高品质的床品，营造温馨浪漫的氛围。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，房间还提供法式浪漫晚餐和24小时客房服务。适合追求浪漫、优雅体验的旅客。',
'便利设施：大床、精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider5.jpg；',
350,
'N310',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式单间',
'提供单人住宿体验的房型，以法国的优雅与精致为核心设计理念。房间布局考究，采用法式装修风格，配备高品质的床品和设施。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的法式餐饮服务和24小时客房服务。适合追求高品质、优雅体验的单身旅客。',
'便利设施：精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N311',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'法式单间',
'提供单人住宿体验的房型，以法国的优雅与精致为核心设计理念。房间布局考究，采用法式装修风格，配备高品质的床品和设施。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的法式餐饮服务和24小时客房服务。适合追求高品质、优雅体验的单身旅客。',
'便利设施：精致的法式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N312',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'三人电竞房',
'专为电竞爱好者设计的住宿体验，房间内配备三台高性能电竞设备、舒适的电竞椅。提供畅快的游戏体验。同时，房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、多人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'/front/images/detail-slider/slider7.jpg',
250,
'N313',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'三人电竞房',
'专为电竞爱好者设计的住宿体验，房间内配备三台高性能电竞设备、舒适的电竞椅。提供畅快的游戏体验。同时，房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、多人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'/front/images/detail-slider/slider7.jpg',
250,
'N314',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式行政房',
'融合了俄罗斯的奢华与文化，房间设计充满浓厚的俄罗斯风格，配备高品质的设施和床品，营造出豪华与舒适的氛围。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还提供正宗的俄式早餐和24小时客房服务。适合追求高品质、独特文化体验的旅客。',
'便利设施：正宗俄式早餐、高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N401',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');



INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式行政房',
'融合了俄罗斯的奢华与文化，房间设计充满浓厚的俄罗斯风格，配备高品质的设施和床品，营造出豪华与舒适的氛围。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还提供正宗的俄式早餐和24小时客房服务。适合追求高品质、独特文化体验的旅客。',
'便利设施：正宗俄式早餐、高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N402',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式套房',
'豪华的住宿体验，融合了俄罗斯的奢华与文化。房间采用浓厚的俄罗斯风格设计，提供高品质的床品和设施完备的浴室。住客可享受VIP级别的服务，如礼宾服务、优先入住和退房等。此外，还有正宗的俄式餐饮服务和24小时客房服务。适合追求高品质、独特文化体验的旅客。',
'便利设施：正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N403',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式套房',
'豪华的住宿体验，融合了俄罗斯的奢华与文化。房间采用浓厚的俄罗斯风格设计，提供高品质的床品和设施完备的浴室。住客可享受VIP级别的服务，如礼宾服务、优先入住和退房等。此外，还有正宗的俄式餐饮服务和24小时客房服务。适合追求高品质、独特文化体验的旅客。',
'便利设施：正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N404',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式三人间',
'提供给三个人的住宿体验，房间采用俄罗斯风格设计，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有正宗的俄式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、独特文化体验的旅客。',
'便利设施：三张床、正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N405',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式三人间',
'提供给三个人的住宿体验，房间采用俄罗斯风格设计，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有正宗的俄式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、独特文化体验的旅客。',
'便利设施：三张床、正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N406',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式标间',
'提供给两个人的住宿体验，房间采用俄罗斯风格设计，配备高品质的床品和设施。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还有正宗的俄式餐饮服务和24小时客房服务。适合情侣或夫妻旅行，追求高品质、独特文化体验的旅客。',
'便利设施：正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N407',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式标间',
'提供给两个人的住宿体验，房间采用俄罗斯风格设计，配备高品质的床品和设施。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还有正宗的俄式餐饮服务和24小时客房服务。适合情侣或夫妻旅行，追求高品质、独特文化体验的旅客。',
'便利设施：正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N408',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式大床房',
'专为情侣或夫妻设计的住宿体验，房间以俄罗斯风格为特色。配备舒适的大床和高品质的床品，营造温馨浪漫的氛围。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，房间还提供正宗的俄式浪漫晚餐和24小时客房服务。适合追求浪漫、独特文化体验的旅客。',
'便利设施：大床、正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider5.jpg',
350,
'N409',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式大床房',
'专为情侣或夫妻设计的住宿体验，房间以俄罗斯风格为特色。配备舒适的大床和高品质的床品，营造温馨浪漫的氛围。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，房间还提供正宗的俄式浪漫晚餐和24小时客房服务。适合追求浪漫、独特文化体验的旅客。',
'便利设施：大床、正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider5.jpg',
350,
'N410',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式单间',
'提供单人住宿体验的房型，房间采用俄罗斯风格设计，配备高品质的床品和设施。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还有正宗的俄式餐饮服务和24小时客房服务。适合追求高品质、独特文化体验的单身旅客。',
'便利设施：正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N411',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'俄式单间',
'提供单人住宿体验的房型，房间采用俄罗斯风格设计，配备高品质的床品和设施。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还有正宗的俄式餐饮服务和24小时客房服务。适合追求高品质、独特文化体验的单身旅客。',
'便利设施：正宗俄式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N412',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'四人电竞房',
'专为电竞爱好者设计的住宿体验，房间内配备四台高性能电竞设备、舒适的电竞椅，提供四人同时游戏的对战空间。房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、多人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'/front/images/detail-slider/slider7.jpg',
300,
'N413',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'四人电竞房',
'专为电竞爱好者设计的住宿体验，房间内配备四台高性能电竞设备、舒适的电竞椅，提供四人同时游戏的对战空间。房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、多人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'/front/images/detail-slider/slider7.jpg',
300,
'N414',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式行政房',
'融合了美国的现代与舒适，房间设计充满美式风情，配备高品质的设施和床品，营造出宾至如归的氛围。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还提供精致的美式早餐和24小时客房服务。适合追求高品质、舒适体验的旅客。',
'便利设施：精致美式早餐、高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N501',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');



INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式行政房',
'融合了美国的现代与舒适，房间设计充满美式风情，配备高品质的设施和床品，营造出宾至如归的氛围。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还提供精致的美式早餐和24小时客房服务。适合追求高品质、舒适体验的旅客。',
'便利设施：精致美式早餐、高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N502',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式套房',
'融合了美国的现代与舒适，房间采用美式风格设计，提供高品质的床品和设施完备的浴室。住客可享受VIP级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的美式餐饮服务和24小时客房服务。适合追求高品质、舒适体验的旅客。',
'便利设施：精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N503',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式套房',
'融合了美国的现代与舒适，房间采用美式风格设计，提供高品质的床品和设施完备的浴室。住客可享受VIP级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的美式餐饮服务和24小时客房服务。适合追求高品质、舒适体验的旅客。',
'便利设施：精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N504',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式三人间',
'提供给三个人的住宿体验，房间采用美式风格设计，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的美式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、舒适体验的旅客。',
'便利设施：三张床、精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N505',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式三人间',
'提供给三个人的住宿体验，房间采用美式风格设计，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的美式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、舒适体验的旅客。',
'便利设施：三张床、精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N506',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式标间',
'提供给两个人的住宿体验，房间采用美式风格设计，配备高品质的床品和设施。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还有精致的美式餐饮服务和24小时客房服务。适合情侣或夫妻旅行，追求高品质、舒适体验的旅客。',
'便利设施：精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N507',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式标间',
'提供给两个人的住宿体验，房间采用美式风格设计，配备高品质的床品和设施。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还有精致的美式餐饮服务和24小时客房服务。适合情侣或夫妻旅行，追求高品质、舒适体验的旅客。',
'便利设施：精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N508',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式大床房',
'专为情侣或夫妻设计的住宿体验，房间以美式风格为特色。配备舒适的大床和高品质的床品，营造温馨浪漫的氛围。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，房间还提供精致的美式浪漫晚餐和24小时客房服务。适合追求浪漫、舒适体验的旅客。',
'便利设施：大床、精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider5.jpg',
350,
'N509',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式大床房',
'专为情侣或夫妻设计的住宿体验，房间以美式风格为特色。配备舒适的大床和高品质的床品，营造温馨浪漫的氛围。住客可享受高级别的服务，如礼宾服务、优先入住和退房等。此外，房间还提供精致的美式浪漫晚餐和24小时客房服务。适合追求浪漫、舒适体验的旅客。',
'便利设施：大床、精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider5.jpg',
350,
'N510',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式单间',
'提供单人住宿体验的房型，房间采用美式风格设计，配备高品质的床品和设施。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还有精致的美式餐饮服务和24小时客房服务。适合追求高品质、舒适体验的单身旅客。',
'便利设施：精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N511',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'美式单间',
'提供单人住宿体验的房型，房间采用美式风格设计，配备高品质的床品和设施。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还有精致的美式餐饮服务和24小时客房服务。适合追求高品质、舒适体验的单身旅客。',
'便利设施：精致美式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋等，提供24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N512',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'五人电竞房',
'专为电竞爱好者设计的住宿体验，房间内配备五台高性能电竞设备、舒适的电竞椅，提供五人同时游戏的对战空间。房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、多人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'/front/images/detail-slider/slider7.jpg',
350,
'N513',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'五人电竞房',
'专为电竞爱好者设计的住宿体验，房间内配备五台高性能电竞设备、舒适的电竞椅，提供五人同时游戏的对战空间。房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、多人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'/front/images/detail-slider/slider7.jpg',
350,
'N514',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式行政房',
'融合了中国的传统与现代元素，房间设计充满中式风情，配备高品质的设施和床品，营造出典雅而舒适的氛围。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还提供精致的中式早餐和24小时客房服务。适合追求高品质、典雅体验的旅客。',
'便利设施：精致中式早餐、高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N601',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');



INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式行政房',
'融合了中国的传统与现代元素，房间设计充满中式风情，配备高品质的设施和床品，营造出典雅而舒适的氛围。住客可享受礼宾服务、优先入住和退房等高级服务。此外，还提供精致的中式早餐和24小时客房服务。适合追求高品质、典雅体验的旅客。',
'便利设施：精致中式早餐、高端办公设备、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider1.jpg',
500,
'N602',
1,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式套房',
'充满中国传统文化韵味的豪华住宿体验。套房内设计融合古典与现代元素，采用高品质的中式家具和装饰，营造出浓郁的中式风情。住客可以享受宽敞的空间，独立的起居、睡眠和工作区域，以及配备齐全的设施，如舒适的床铺、豪华的浴室、娱乐设备等。此外，还提供中式餐饮服务和24小时客房服务，满足住客的各种需求。中式套房适合追求中国传统文化体验、注重高品质生活的旅客。',
'便利设施：精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N603',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式套房',
'充满中国传统文化韵味的豪华住宿体验。套房内设计融合古典与现代元素，采用高品质的中式家具和装饰，营造出浓郁的中式风情。住客可以享受宽敞的空间，独立的起居、睡眠和工作区域，以及配备齐全的设施，如舒适的床铺、豪华的浴室、娱乐设备等。此外，还提供中式餐饮服务和24小时客房服务，满足住客的各种需求。中式套房适合追求中国传统文化体验、注重高品质生活的旅客。',
'便利设施：精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider2.jpg',
300,
'N604',
2,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式三人间',
'提供给三个人的住宿体验，房间采用中式风格设计，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的中式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、传统体验的旅客。',
'便利设施：三张床、精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N605',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式三人间',
'提供给三个人的住宿体验，房间采用中式风格设计，配备高品质的床品和设施。住客可以享受高级别的服务，如礼宾服务、优先入住和退房等。此外，还有精致的中式餐饮服务和24小时客房服务。适合家庭或朋友一起旅行，追求高品质、传统体验的旅客。',
'便利设施：三张床、精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider3.jpg',
260,
'N606',
3,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式标间',
'提供给两个人的住宿体验，以中国传统文化为设计灵感。房间内布置典雅，床品舒适，设施完善，营造出温馨宁静的氛围。住客可以享受到中式风格的独特魅力，同时酒店也提供一系列贴心服务，如24小时前台服务、行李寄存等，以满足不同住客的需求。中式标间适合情侣、夫妻或商务人士等寻求高品质和传统氛围的旅客。',
'便利设施：精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N607',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式标间',
'提供给两个人的住宿体验，以中国传统文化为设计灵感。房间内布置典雅，床品舒适，设施完善，营造出温馨宁静的氛围。住客可以享受到中式风格的独特魅力，同时酒店也提供一系列贴心服务，如24小时前台服务、行李寄存等，以满足不同住客的需求。中式标间适合情侣、夫妻或商务人士等寻求高品质和传统氛围的旅客。',
'便利设施：精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider4.jpg',
200,
'N608',
4,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式大床房',
'提供给单人或情侣的住宿体验，以中国传统文化为设计灵感。房间内布置典雅，床品舒适，设施完善，营造出温馨宁静的氛围。住客可以享受到中式风格的独特魅力，同时酒店也提供一系列贴心服务，如24小时前台服务、行李寄存等，以满足不同住客的需求。中式大床房适合寻求高品质和传统氛围的单身旅客或情侣。',
'便利设施：大床、精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider5.jpg',
350,
'N609',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式大床房',
'提供给单人或情侣的住宿体验，以中国传统文化为设计灵感。房间内布置典雅，床品舒适，设施完善，营造出温馨宁静的氛围。住客可以享受到中式风格的独特魅力，同时酒店也提供一系列贴心服务，如24小时前台服务、行李寄存等，以满足不同住客的需求。中式大床房适合寻求高品质和传统氛围的单身旅客或情侣。',
'便利设施：大床、精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider5.jpg',
350,
'N610',
5,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'中式单间',
'提供单人住宿体验的房型，以中国传统文化为设计灵感。房间内布置典雅，床品舒适，设施完善，营造出温馨宁静的氛围。住客可以享受到中式风格的独特魅力，同时酒店也提供一系列贴心服务，如24小时前台服务、行李寄存等，以满足不同住客的需求。中式单间适合寻求高品质和传统氛围的单身旅客。',
'便利设施：精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N611',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'提供单人住宿体验的房型，以中国传统文化为设计灵感。房间内布置典雅，床品舒适，设施完善，营造出温馨宁静的氛围。住客可以享受到中式风格的独特魅力，同时酒店也提供一系列贴心服务，如24小时前台服务、行李寄存等，以满足不同住客的需求。中式单间适合寻求高品质和传统氛围的单身旅客。',
'便利设施：精致中式早餐、免费Wi-Fi、私人保险箱、迷你吧、咖啡/茶制作设备、智能电视、私人浴室、浴袍和拖鞋、24小时客房服务、礼宾服务...',
'/front/images/detail-slider/slider6.jpg',
150,
'N612',
6,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'五人电竞房',
'专为电竞爱好者设计的住宿体验，房间内配备五台高性能电竞设备、舒适的电竞椅，提供五人同时游戏的对战空间。房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、多人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'/front/images/detail-slider/slider7.jpg',
350,
'N613',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


INSERT INTO `post` (`create_by`,`create_time`,`post_title`,`post_content`,`post_summary`,`post_thumbnail`,`price`,`number`,`cate_id`,`post_editor`)
  VALUES('12345678910',NOW(),
'五人电竞房',
'专为电竞爱好者设计的住宿体验，房间内配备五台高性能电竞设备、舒适的电竞椅，提供五人同时游戏的对战空间。房间还设有独立休息区，方便住客休息和放松。高速网络、专业音响系统等设施确保游戏的顺畅进行和沉浸感。适合与朋友一起享受电竞乐趣的旅客。',
'便利设施：高性能电竞设备、舒适电竞椅、多人对战空间、独立休息区、高速网络、专业音响系统、零食和饮料...',
'/front/images/detail-slider/slider7.jpg',
350,
'N614',
7,
'<p><br></p ><p><img+src="/front/images/detail-slider/slider1.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider2.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider3.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider4.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider5.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider6.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider7.jpg"+style="width:+100px;"+class="fr-fic+fr-dib">
<img+src="/front/images/detail-slider/slider8.jpg"+style="width:+100px;"+class="fr-fic+fr-dib"></p >');


